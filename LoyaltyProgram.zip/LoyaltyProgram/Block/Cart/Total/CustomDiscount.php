<?php

namespace Icreative\LoyaltyProgram\Block\Cart\Total;

use Magento\Framework\View\Element\Template;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Sales\Model\Config;

class CustomDiscount extends \Magento\Checkout\Block\Total\DefaultTotal
{
    protected $priceCurrency;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\Config $salesConfig,
        PriceCurrencyInterface $priceCurrency,
        array $data = []
    ) {
        $this->priceCurrency = $priceCurrency;
        parent::__construct($context, $customerSession, $checkoutSession, $salesConfig, $data);
    }

    public function getTotal(): ?Total
    {
        $totals = $this->getTotals();
        if (isset($totals['customdiscount'])) {
            return $totals['customdiscount'];
        }
        return null;
    }

    public function getDiscountAmount(): float
    {
        $total = $this->getTotal();
        return $total ? (float) $total->getValue() : 0.0;
    }

    public function getLabel(): string
    {
        $total = $this->getTotal();
        return $total ? (string) $total->getTitle() : (string) __('Loyalty Discount');
    }

    public function getFormattedDiscount(): string
    {
        $amount = $this->getDiscountAmount();
        if ($amount >= 0) {
            return '';
        }
        return $this->priceCurrency->format($amount, false);
    }
   
    public function canDisplay(): bool
    {
        return $this->getDiscountAmount() < 0;
    }
}
