<?php
namespace Icreative\LoyaltyProgram\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Customer\Api\CustomerRepositoryInterface;

class LoyaltyTier extends Template
{
    protected $resource;
    protected $_customerSession;
    private $customerRepository;

    public function __construct(
    Template\Context $context,
    ResourceConnection $resource,
    CustomerSession $customerSession,
    CustomerRepositoryInterface $customerRepository,
    array $data = []
    ) {
         $this->resource = $resource;
        $this->_customerSession = $customerSession;
        $this->customerRepository = $customerRepository;
        parent::__construct($context, $data);
    }

    public function isCustomerLoggedIn()
    {
        return $this->_customerSession->isLoggedIn();
    }

    public function getCustomTableData()
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('loyalty_tiers');
        
        $select = $connection->select()->from($tableName);
        return $connection->fetchAll($select);
    }

    public function getCustomerLifetimeSpend()
    {
        if (!$this->_customerSession->isLoggedIn()) {
            return 0;
        }
        
        $customerId = $this->_customerSession->getCustomerId();
        $customer = $this->customerRepository->getById($customerId);
        $attribute = $customer->getCustomAttribute('lifetime_spend');
        
        return $attribute ? $attribute->getValue() : 0;
    }

    public function getLoyaltyTiers()
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('loyalty_tiers');
        
        $select = $connection->select()
            ->from($tableName)
            ->where('status = ?', 1)
            ->order('min_lifetime_spend ASC');
        
        return $connection->fetchAll($select);
    }

    public function getCurrentCustomerTier()
    {
        if (!$this->_customerSession->isLoggedIn()) {
            return 'Guest';
        }
        
        $customerId = $this->_customerSession->getCustomerId();
        $customer = $this->customerRepository->getById($customerId);
        $attribute = $customer->getCustomAttribute('custom_customer_attribute');
        
        return $attribute ? $attribute->getValue() : 'Bronze';
    }
 
    public function getNextTierInfo()
    {
        $currentSpend = $this->getCustomerLifetimeSpend();
        $tiers = $this->getLoyaltyTiers();
        
        foreach ($tiers as $tier) {
            if ($tier['min_lifetime_spend'] > $currentSpend) {
                return [
                    'name' => $tier['loyalty_tier_name'],
                    'spend_needed' => $tier['min_lifetime_spend'] - $currentSpend
                ];
            }
        }
        
        return null;
    }

}

