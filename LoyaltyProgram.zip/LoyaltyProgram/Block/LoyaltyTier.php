<?php
/**
 * LoyaltyTier block.
 *
 * Powers the customer-facing "Loyalty Tier" page in My Account.
 * Provides all data needed by loyaltytier.phtml including:
 *  - current tier, lifetime spend, progress %
 *  - remaining monthly usage from loyalty_discount_usage table
 *  - next tier information
 */

namespace Icreative\LoyaltyProgram\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Customer\Api\CustomerRepositoryInterface;

class LoyaltyTier extends Template
{
    protected $resource;
    protected $_customerSession;
    private $customerRepository;

    /** @var array|null — cached customer data within one render */
    private $cachedCustomer = null;
    private $cachedTierData = null;

    public function __construct(
        Template\Context $context,
        ResourceConnection $resource,
        CustomerSession $customerSession,
        CustomerRepositoryInterface $customerRepository,
        array $data = []
    ) {
        $this->resource           = $resource;
        $this->_customerSession   = $customerSession;
        $this->customerRepository = $customerRepository;
        parent::__construct($context, $data);
    }

    // =========================================================================
    // Public API used by the template
    // =========================================================================

    public function isCustomerLoggedIn(): bool
    {
        return $this->_customerSession->isLoggedIn();
    }

    public function getCustomerLifetimeSpend(): float
    {
        $customer = $this->getCustomer();
        if (!$customer) {
            return 0.0;
        }
        $attr = $customer->getCustomAttribute('lifetime_spend');
        return $attr ? (float) $attr->getValue() : 0.0;
    }

    public function getCurrentCustomerTier(): string
    {
        $customer = $this->getCustomer();
        if (!$customer) {
            return '';
        }
        $attr = $customer->getCustomAttribute('custom_customer_attribute');
        return $attr ? (string) $attr->getValue() : '';
    }

    public function getLoyaltyTiers(): array
    {
        $connection = $this->resource->getConnection();
        $tableName  = $this->resource->getTableName('loyalty_tiers');

        $select = $connection->select()
            ->from($tableName)
            ->where('status = ?', 1)
            ->order('min_lifetime_spend ASC');

        return $connection->fetchAll($select);
    }

    public function getCurrentTierData(): array
    {
        if ($this->cachedTierData !== null) {
            return $this->cachedTierData;
        }

        $tierName = $this->getCurrentCustomerTier();
        if (!$tierName) {
            $this->cachedTierData = [];
            return [];
        }

        $connection = $this->resource->getConnection();
        $table      = $this->resource->getTableName('loyalty_tiers');

        $select = $connection->select()
            ->from($table)
            ->where('loyalty_tier_name = ?', $tierName)
            ->where('status = ?', 1)
            ->limit(1);

        $row = $connection->fetchRow($select);
        $this->cachedTierData = $row ?: [];
        return $this->cachedTierData;
    }

    /**
     * Returns info about the next tier above the customer's current spend.
     * Returns null if the customer is already at the highest tier.
     */
    public function getNextTierInfo(): ?array
    {
        $currentSpend = $this->getCustomerLifetimeSpend();
        $tiers        = $this->getLoyaltyTiers();

        foreach ($tiers as $tier) {
            if ((float) $tier['min_lifetime_spend'] > $currentSpend) {
                return [
                    'name'         => $tier['loyalty_tier_name'],
                    'spend_needed' => $tier['min_lifetime_spend'] - $currentSpend,
                    'discount'     => $tier['discount_amount'],
                    'usage_limit'  => $tier['usage_limit'],
                ];
            }
        }

        return null; // top tier
    }

    /**
     * Progress percentage toward the next tier (0–100).
     */
    public function getProgressPercentage(): int
    {
        $currentSpend   = $this->getCustomerLifetimeSpend();
        $tiers          = $this->getLoyaltyTiers();
        $currentTierMin = 0.0;
        $nextTierMin    = null;

        foreach ($tiers as $tier) {
            if ((float) $tier['min_lifetime_spend'] <= $currentSpend) {
                $currentTierMin = (float) $tier['min_lifetime_spend'];
            } else {
                $nextTierMin = (float) $tier['min_lifetime_spend'];
                break;
            }
        }

        if ($nextTierMin === null) {
            return 100;
        }

        $tierRange      = $nextTierMin - $currentTierMin;
        $progressInTier = $currentSpend - $currentTierMin;

        return (int) min(100, max(0, ($progressInTier / $tierRange) * 100));
    }

    /**
     * How many more times this customer can use the loyalty discount.
     * Returns -1 for unlimited, 0 when exhausted.
     */
    public function getRemainingUsage(): int
    {
        $tierData = $this->getCurrentTierData();
        if (!$tierData) {
            return 0;
        }

        $usageLimit = (int) ($tierData['usage_limit'] ?? 0);
        if ($usageLimit <= 0) {
            return -1; // unlimited
        }

        $used = $this->getCustomerUsageCount();
        return max(0, $usageLimit - $used);
    }

    /**
     * How many times the customer has used the discount in total.
     */
    public function getCustomerUsageCount(): int
    {
        $customer = $this->getCustomer();
        if (!$customer) {
            return 0;
        }
        
        $attr = $customer->getCustomAttribute('loyalty_discount_used');
        return ($attr && $attr->getValue()) ? (int) $attr->getValue() : 0;
    }

    /**
     * Get the customer's total discount limit.
     */
    public function getCustomerTotalLimit(): int
    {
        $customer = $this->getCustomer();
        if (!$customer) {
            return 0;
        }
        
        $attr = $customer->getCustomAttribute('loyalty_discount_total_limit');
        return ($attr && $attr->getValue()) ? (int) $attr->getValue() : 0;
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    private function getCustomer(): ?\Magento\Customer\Api\Data\CustomerInterface
    {
        if ($this->cachedCustomer !== null) {
            return $this->cachedCustomer ?: null;
        }

        if (!$this->_customerSession->isLoggedIn()) {
            $this->cachedCustomer = false;
            return null;
        }

        try {
            $this->cachedCustomer = $this->customerRepository->getById(
                (int) $this->_customerSession->getCustomerId()
            );
        } catch (\Exception $e) {
            $this->cachedCustomer = false;
        }

        return $this->cachedCustomer ?: null;
    }
}
