
define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/totals'
], function (Component, totals) {
    'use strict';

    return Component.extend({
        defaults: {
            // Default template — overridden per layout context via checkout_cart_index.xml
            template: 'Icreative_LoyaltyProgram/cart/totals/custom-discount'
        },

        /**
         * Get the customdiscount totals segment.
         * Returns null when no discount applies (guest, no tier, usage exhausted).
         * @return {Object|null}
         */
        getDiscountSegment: function () {
            return totals.getSegment('customdiscount');
        },

        /**
         * Raw numeric value — always negative when discount is active.
         * e.g. -15.00
         * @return {Number}
         */
        getPureValue: function () {
            var segment = this.getDiscountSegment();
            return segment ? parseFloat(segment.value) : 0;
        },

        /**
         * Only show when value is strictly negative.
         * Prevents phantom row when segment exists but value is 0.
         * @return {Boolean}
         */
        isDisplayed: function () {
            return this.getPureValue() < 0;
        },

        /**
         * Dynamic label from PHP — e.g. "Gold Program 10% Discount".
         * Comes from CustomDiscount::fetch() → segment.title.
         * @return {String|null}
         */
        getTitle: function () {
            var segment = this.getDiscountSegment();
            return segment ? segment.title : null;
        },

        /**
         * Formatted price string — e.g. "-$15.00".
         * @return {String}
         */
        getValue: function () {
            return this.getFormattedPrice(this.getPureValue());
        }
    });
});
