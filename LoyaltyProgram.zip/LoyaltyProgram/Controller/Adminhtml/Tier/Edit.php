<?php

namespace Icreative\LoyaltyProgram\Controller\Adminhtml\Tier;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Icreative\LoyaltyProgram\Model\TiersFactory;
use Magento\Framework\Registry;

class Edit extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_LoyaltyProgram::tier';

    protected PageFactory $resultPageFactory;
    protected TiersFactory $tiersFactory;
    protected Registry $coreRegistry;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        TiersFactory $tiersFactory,
        Registry $coreRegistry
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->tiersFactory     = $tiersFactory;
        $this->coreRegistry      = $coreRegistry;
    }

    public function execute()
    {
        $tierId = (int)$this->getRequest()->getParam('loyalty_tier_id');
        $tier   = $this->tiersFactory->create();

        if ($tierId) {
            $tier->load($tierId);
            if (!$tier->getId()) {
                $this->messageManager->addErrorMessage(__('This Tier no longer exists.'));
                return $this->resultRedirectFactory->create()->setPath('*/*/');
            }
        }

        $this->coreRegistry->register('current_tier', $tier);

        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Icreative_LoyaltyProgram::tier');

        $title = $tierId ? __('Edit Tier') : __('Add New Tier');
        $resultPage->getConfig()->getTitle()->prepend($title);

        return $resultPage;
    }
}