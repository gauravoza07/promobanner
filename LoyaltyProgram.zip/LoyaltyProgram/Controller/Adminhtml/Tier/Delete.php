<?php

namespace Icreative\LoyaltyProgram\Controller\Adminhtml\Tier;

use Magento\Backend\App\Action;
use Icreative\LoyaltyProgram\Model\TiersFactory;

class Delete extends Action
{
    protected $tiersFactory;

    public function __construct(
        Action\Context $context,
        TiersFactory $tiersFactory
    ) {
        parent::__construct($context);
        $this->tiersFactory = $tiersFactory;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('loyalty_tier_id');

        if ($id) {
            $model = $this->tiersFactory->create()->load($id);
            $model->delete();

            $this->messageManager->addSuccessMessage(__('Tier Deleted'));
        }

        return $this->_redirect('*/*/index');
    }
}