<?php

namespace Icreative\LoyaltyProgram\Ui\DataProvider;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Icreative\LoyaltyProgram\Model\ResourceModel\Tiers\CollectionFactory;

class FormDataProvider extends AbstractDataProvider
{
    protected $loadedData;

    public function __construct(
        string $name,
        string $primaryFieldName,
        string $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();

        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();

        foreach ($items as $item) {
            $this->loadedData[$item->getId()] = $item->getData();
        }

        return $this->loadedData;
    }
}