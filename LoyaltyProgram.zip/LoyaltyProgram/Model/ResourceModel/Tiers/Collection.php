<?php
namespace Icreative\LoyaltyProgram\Model\ResourceModel\Tiers;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'loyalty_tier_id';
    
    /**
     * Dependency Initilization
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init(
            \Icreative\LoyaltyProgram\Model\Tiers::class,
            \Icreative\LoyaltyProgram\Model\ResourceModel\Tiers::class
        );
    }
}