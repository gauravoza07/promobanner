<?php
namespace Icreative\LoyaltyProgram\Model;

use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
use Magento\Shipping\Model\Rate\ResultFactory;
use Magento\Quote\Model\Quote\Address\RateCollectorInterface;
use Magento\Customer\Model\Session as CustomerSession;

class Carrier implements RateCollectorInterface
{
    protected $_code = 'loyaltydiscount';

    protected $rateErrorFactory;
    protected $rateResultFactory;
    protected $rateMethodFactory;
    protected $customerSession;

    public function __construct(
        ErrorFactory $rateErrorFactory,
        ResultFactory $rateResultFactory,
        MethodFactory $rateMethodFactory,
        CustomerSession $customerSession
    ) {
        $this->rateErrorFactory = $rateErrorFactory;
        $this->rateResultFactory = $rateResultFactory;
        $this->rateMethodFactory = $rateMethodFactory;
        $this->customerSession = $customerSession;
    }

    public function collectRates(\Magento\Quote\Model\Quote\Address\RateRequest $request)
    {
        if (!$this->customerSession->isLoggedIn()) {
            return false;
        }

        $customer = $this->customerSession->getCustomer();
        $tierAttribute = $customer->getCustomAttribute('custom_customer_attribute');
        
        if (!$tierAttribute) {
            return false;
        }

        $currentTier = $tierAttribute->getValue();
        
        // Get tier discount info
        $resource = \Magento\Framework\App\ObjectManager::getInstance()
            ->get(\Magento\Framework\App\ResourceConnection::class);
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('loyalty_tiers');

        $select = $connection->select()
            ->from($tableName)
            ->where('loyalty_tier_name = ?', $currentTier)
            ->where('status = ?', 1);

        $tier = $connection->fetchRow($select);

        if (!$tier || $tier['discount_amount'] <= 0) {
            return false;
        }

        $result = $this->rateResultFactory->create();
        $method = $this->rateMethodFactory->create();

        $method->setCarrier($this->_code);
        $method->setCarrierTitle('Loyalty Discount');
        $method->setMethod($this->_code);
        $method->setMethodTitle($currentTier . ' Discount');
        $method->setPrice(-($tier['discount_amount'])); // Negative price for discount
        $method->setCost(-($tier['discount_amount']));

        $result->append($method);
        return $result;
    }

    public function getAllowedMethods()
    {
        return [$this->_code => $this->getConfigData('name')];
    }
}
