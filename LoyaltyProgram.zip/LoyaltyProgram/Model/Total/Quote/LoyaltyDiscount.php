<?php
namespace Icreative\LoyaltyProgram\Model\Total\Quote;

use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;

class LoyaltyDiscount extends AbstractTotal
{
    protected $code = 'loyalty_discount';

    public function collect(
        Quote $quote,
        Quote\Address\Total $total
    ) {
        parent::collect($quote, $total);

        $loyaltyDiscount = $quote->getData('loyalty_discount_amount');
        
        if ($loyaltyDiscount > 0) {
            $total->setTotalAmount($this->getCode(), $loyaltyDiscount);
            $total->setBaseTotalAmount($this->getCode(), $loyaltyDiscount);
            
            $quote->setData('loyalty_discount_amount', $loyaltyDiscount);
        }

        return $this;
    }

    public function fetch(
        Quote $quote,
        Quote\Address\Total $total
    ) {
        $loyaltyDiscount = $quote->getData('loyalty_discount_amount');
        $loyaltyTier = $quote->getData('loyalty_tier_name');
        
        if ($loyaltyDiscount > 0 && $loyaltyTier) {
            return [
                'code' => $this->getCode(),
                'title' => __('Loyalty Discount (%1)', $loyaltyTier),
                'value' => $loyaltyDiscount
            ];
        }

        return null;
    }

    public function getLabel()
    {
        return __('Loyalty Discount');
    }
}
