<?php
/**
 * UsageLimitValidator
 *
 * Helper service that checks whether the current customer can still receive
 * a loyalty discount this month. Reads from loyalty_discount_usage
 * (written by UpdateLifetimeSpend observer after each completed order).
 *
 * This class is not used internally by CustomDiscount (which has its own
 * inline check), but is available for injection into plugins or custom code.
 */

namespace Icreative\LoyaltyProgram\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class UsageLimitValidator
{
    protected $customerSession;
    protected $resource;
    protected $customerRepository;
    protected $logger;

    public function __construct(
        CustomerSession $customerSession,
        ResourceConnection $resource,
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->customerSession    = $customerSession;
        $this->resource           = $resource;
        $this->customerRepository = $customerRepository;
        $this->logger             = $logger;
    }

    /**
     * Returns true if the logged-in customer can still use the loyalty discount
     * based on their total usage limit.
     */
    public function canApplyDiscount(): bool
    {
        try {
            if (!$this->customerSession->isLoggedIn()) {
                return false;
            }

            $tierData = $this->getCustomerCurrentTierData();
            if (!$tierData) {
                return false;
            }

            $usageLimit = (int) ($tierData['usage_limit'] ?? 0);
            if ($usageLimit <= 0) {
                return true; // unlimited
            }

            return $this->getCustomerUsageCount() < $usageLimit;
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram UsageLimitValidator error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Returns the active loyalty tier row for the current customer, or null.
     */
    public function getCustomerCurrentTierData(): ?array
    {
        if (!$this->customerSession->isLoggedIn()) {
            return null;
        }

        try {
            $customerId = (int) $this->customerSession->getCustomerId();
            $customer   = $this->customerRepository->getById($customerId);
            $attr       = $customer->getCustomAttribute('custom_customer_attribute');

            if (!$attr || !$attr->getValue()) {
                return null;
            }

            $tierName   = $attr->getValue();
            $connection = $this->resource->getConnection();
            $tierTable  = $this->resource->getTableName('loyalty_tiers');

            $select = $connection->select()
                ->from($tierTable)
                ->where('loyalty_tier_name = ?', $tierName)
                ->where('status = ?', 1)
                ->limit(1);

            $row = $connection->fetchRow($select);
            return $row ?: null;
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram getCustomerCurrentTierData error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * How many times has the customer used the loyalty discount in total?
     */
    public function getCustomerUsageCount(): int
    {
        try {
            if (!$this->customerSession->isLoggedIn()) {
                return 0;
            }

            $customerId = (int) $this->customerSession->getCustomerId();
            $customer = $this->customerRepository->getById($customerId);
            $attr = $customer->getCustomAttribute('loyalty_discount_used');
            return ($attr && $attr->getValue()) ? (int) $attr->getValue() : 0;
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram getCustomerUsageCount error: ' . $e->getMessage());
            return 0;
        }
    }
}
