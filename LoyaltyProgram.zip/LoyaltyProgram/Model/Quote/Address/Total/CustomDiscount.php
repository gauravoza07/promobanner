<?php


namespace Icreative\LoyaltyProgram\Model\Quote\Address\Total;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Total;
use Psr\Log\LoggerInterface;

class CustomDiscount extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
    protected $priceCurrency;
    protected $customerSession;
    protected $resource;
    protected $customerRepository;
    protected $logger;

    /** @var array|null|false */
    private $cachedTierData = null;

    public function __construct(
        PriceCurrencyInterface $priceCurrency,
        CustomerSession $customerSession,
        ResourceConnection $resource,
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->priceCurrency      = $priceCurrency;
        $this->customerSession    = $customerSession;
        $this->resource           = $resource;
        $this->customerRepository = $customerRepository;
        $this->logger             = $logger;
        $this->setCode('customdiscount');
    }

    public function collect(
        Quote $quote,
        ShippingAssignmentInterface $shippingAssignment,
        Total $total
    ): self {
        parent::collect($quote, $shippingAssignment, $total);

        $total->setTotalAmount('customdiscount', 0);
        $total->setBaseTotalAmount('customdiscount', 0);
        $this->cachedTierData = null;

        if (!count($shippingAssignment->getItems())) {
            return $this;
        }

        try {
            $customerId = $this->resolveCustomerId($quote);
            if (!$customerId) {
                return $this;
            }

            $tierData = $this->getCustomerTierData($customerId);
            if (!$tierData) {
                return $this;
            }

            $discountAmount = $this->computeDiscount($quote, $tierData, $customerId);

            // Debug logging
            $this->logger->info('[LoyaltyProgram] Discount calculation', [
                'customer_id' => $customerId,
                'tier_data' => $tierData,
                'discount_amount' => $discountAmount,
                'quote_subtotal' => $quote->getSubtotal()
            ]);

            if ($discountAmount < 0) {
                $total->addTotalAmount('customdiscount', $discountAmount);
                $total->addBaseTotalAmount('customdiscount', $discountAmount);
                $quote->setData('loyalty_discount_amount', $discountAmount);
                $label = $this->buildLabel($tierData);
                $quote->setData('loyalty_discount_label', $label);
                $this->logger->info('[LoyaltyProgram] Discount applied', [
                    'amount' => $discountAmount,
                    'label' => $label
                ]);
            } else {
                $quote->setData('loyalty_discount_amount', 0);
                $quote->setData('loyalty_discount_label', '');
                $this->logger->info('[LoyaltyProgram] No discount applied', ['amount' => $discountAmount]);
            }
        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] collect() exception: ' . $e->getMessage());
        }

        return $this;
    }

    public function fetch(Quote $quote, Total $total): array
    {
        $amount = (float) $total->getTotalAmount('customdiscount');

        // Debug logging
        $this->logger->info('[LoyaltyProgram] fetch() called', [
            'total_amount' => $amount,
            'loyalty_discount_amount' => $quote->getData('loyalty_discount_amount')
        ]);

        if ($amount >= 0) {
            $amount = (float) $quote->getData('loyalty_discount_amount');
        }

        if ($amount == 0) {
            $this->logger->info('[LoyaltyProgram] fetch() returning empty array - no discount');
            return [];
        }

        $label = (string) $quote->getData('loyalty_discount_label');
        if (!$label) {
            $customerId = $this->resolveCustomerId($quote);
            if ($customerId) {
                $tierData = $this->getCustomerTierData($customerId);
                $label = $tierData ? $this->buildLabel($tierData) : '';
            }
        }
        if (!$label) {
            $label = (string) __('Loyalty Discount');
        }

        return [
            'code'  => $this->getCode(),
            'title' => $label,
            'value' => $amount,
        ];
    }

    private function resolveCustomerId(Quote $quote): int
    {
        $id = (int) $quote->getCustomerId();
        if ($id) {
            return $id;
        }
        try {
            $id = (int) $this->customerSession->getCustomerId();
        } catch (\Exception $e) {
            // session not available
        }
        return $id;
    }

    private function getCustomerTierData(int $customerId)
    {
        if ($this->cachedTierData !== null) {
            return $this->cachedTierData;
        }

        $this->cachedTierData = false;

        try {
            $customer = $this->customerRepository->getById($customerId);
            $tierName = $this->getAssignedTierName($customer);
            if ($tierName) {
                $this->cachedTierData = $this->fetchTierByName($tierName);
            }
            if (!$this->cachedTierData) {
                $this->cachedTierData = $this->fetchTierByLifetimeSpend($customer);
            }
        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] getCustomerTierData() exception: ' . $e->getMessage());
        }

        return $this->cachedTierData;
    }

    private function getAssignedTierName($customer): ?string
    {
        $attr = $customer->getCustomAttribute('custom_customer_attribute');
        return ($attr && $attr->getValue()) ? trim((string) $attr->getValue()) : null;
    }

    private function fetchTierByName(string $tierName)
    {
        $conn  = $this->resource->getConnection();
        $table = $this->resource->getTableName('loyalty_tiers');
        $row   = $conn->fetchRow(
            $conn->select()->from($table)
                ->where('loyalty_tier_name = ?', $tierName)
                ->where('status = ?', 1)
                ->limit(1)
        );
        return $row ?: false;
    }

    private function fetchTierByLifetimeSpend($customer)
    {
        $attr          = $customer->getCustomAttribute('lifetime_spend');
        $lifetimeSpend = $attr ? (float) $attr->getValue() : 0.0;
        if ($lifetimeSpend <= 0) {
            return false;
        }
        $conn  = $this->resource->getConnection();
        $table = $this->resource->getTableName('loyalty_tiers');
        $row   = $conn->fetchRow(
            $conn->select()->from($table)
                ->where('min_lifetime_spend <= ?', $lifetimeSpend)
                ->where('status = ?', 1)
                ->order('min_lifetime_spend DESC')
                ->limit(1)
        );
        return $row ?: false;
    }

    private function computeDiscount(Quote $quote, array $tierData, int $customerId): float
    {
        $pct = (float) ($tierData['discount_amount'] ?? 0);
        if ($pct <= 0) {
            return 0.0;
        }
        $subtotal = (float) $quote->getSubtotal();
        if ($subtotal <= 0) {
            return 0.0;
        }
        if (!$this->isWithinUsageLimit($tierData, $customerId)) {
            return 0.0;
        }
        return -(round($subtotal * $pct / 100, 4));
    }

    private function isWithinUsageLimit(array $tierData, int $customerId): bool
    {
        $limit = (int) ($tierData['usage_limit'] ?? 0);
        if ($limit <= 0) {
            return true;
        }
        return $this->getCustomerUsageCount($customerId) < $limit;
    }

    private function getCustomerUsageCount(int $customerId): int
    {
        try {
            $customer = $this->customerRepository->getById($customerId);
            $attr = $customer->getCustomAttribute('loyalty_discount_used');
            return ($attr && $attr->getValue()) ? (int) $attr->getValue() : 0;
        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] getCustomerUsageCount() exception: ' . $e->getMessage());
            return 0;
        }
    }

    private function buildLabel(array $tierData): string
    {
        if (!empty($tierData['loyalty_tier_name']) && isset($tierData['discount_amount'])) {
            return (string) __(
                '%1 Program %2% Discount',
                $tierData['loyalty_tier_name'],
                (int) $tierData['discount_amount']
            );
        }
        return (string) __('Loyalty Discount');
    }
}
