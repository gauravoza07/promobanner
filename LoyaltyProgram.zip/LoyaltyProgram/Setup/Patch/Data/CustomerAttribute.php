<?php
namespace Icreative\LoyaltyProgram\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class CustomerAttribute implements DataPatchInterface
{
    private $moduleDataSetup;

   
    protected $customerSetupFactory;


    private $attributeSetFactory;

  
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory,
        AttributeSetFactory $attributeSetFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }

   
    public function apply()
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        $customerSetup->addAttribute(Customer::ENTITY, 'custom_customer_attribute', [
            'type' => 'varchar',
            'label' => 'Loyalty Tier',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 999,
            'system' => 0,
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'lifetime_spend', [
            'type' => 'decimal',
            'label' => 'Lifetime Spend',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 1000,
            'system' => 0,
        ]);

        $attributesToSave = ['custom_customer_attribute', 'lifetime_spend'];

        foreach ($attributesToSave as $attributeCode) {
            $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, $attributeCode)
                ->addData([
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['adminhtml_customer'],
                ]);
            $attribute->save();
        }
    }


    public static function getDependencies()
    {
        return [];
    }

  
    public function getAliases()
    {
        return [];
    }
}