<?php
namespace Icreative\LoyaltyProgram\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class CustomerAttributev3 implements DataPatchInterface
{
    private $moduleDataSetup;

   
    protected $customerSetupFactory;


    private $attributeSetFactory;

  
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory,
        AttributeSetFactory $attributeSetFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }

   
    public function apply()
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        $customerSetup->addAttribute(Customer::ENTITY, 'custom_customer_attribute', [
            'type' => 'varchar',
            'label' => 'Loyalty Tier',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 999,
            'system' => 0,
            'note' => 'Customer loyalty tier name (e.g., Bronze, Silver, Gold)'
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'lifetime_spend', [
            'type' => 'decimal',
            'label' => 'Lifetime Spend',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 1000,
            'system' => 0,
            'default' => 0,
            'note' => 'Total amount customer has spent across all orders'
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'loyalty_discount_used', [
            'type' => 'int',
            'label' => 'Loyalty Discount Used',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 1001,
            'system' => 0,
            'default' => 0,
            'note' => 'Number of times customer has used loyalty discount'
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'loyalty_discount_total_limit', [
            'type' => 'int',
            'label' => 'Loyalty Discount Total Limit',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 1002,
            'system' => 0,
            'default' => 0,
            'note' => 'Maximum number of loyalty discounts customer can use'
        ]);

        // Alternative attribute name for new projects
        $customerSetup->addAttribute(Customer::ENTITY, 'loyalty_tier', [
            'type' => 'varchar',
            'label' => 'Loyalty Tier',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'position' => 998,
            'system' => 0,
            'note' => 'Customer loyalty tier name (alternative to custom_customer_attribute)'
        ]);

        $attributesToSave = [
            'custom_customer_attribute', 
            'lifetime_spend', 
            'loyalty_discount_used', 
            'loyalty_discount_total_limit',
            'loyalty_tier' // Alternative attribute name
        ];

        foreach ($attributesToSave as $attributeCode) {
            $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, $attributeCode)
                ->addData([
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['adminhtml_customer', 'customer_account_edit'],
                ]);
            $attribute->save();
        }
    }

    public static function getDependencies()
    {
        return [];
    }

    public function getAliases()
    {
        return [];
    }
}
