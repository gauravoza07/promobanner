<?php
/**
 * UpdateLifetimeSpend observer.
 *
 * Fires: sales_order_save_after
 *
 * When an order reaches STATE_COMPLETE:
 *  1. Re-calculates the customer's total lifetime spend from all complete orders.
 *  2. Saves the updated lifetime_spend customer attribute.
 *  3. Re-assigns the loyalty tier via AssignTier.
 *  4. If the completed order carried a loyalty discount, records one usage row
 *     in loyalty_discount_usage for this month's quota tracking.
 *
 * STATE_PROCESSING orders do NOT count toward lifetime spend — they haven't
 * been confirmed as revenue yet. Adjust the state check below if your store
 * considers processing = complete.
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Psr\Log\LoggerInterface;

class UpdateLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $orderCollectionFactory;
    protected $resource;
    protected $logger;
    protected $assignTier;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        OrderCollectionFactory $orderCollectionFactory,
        ResourceConnection $resource,
        LoggerInterface $logger,
        AssignTier $assignTier
    ) {
        $this->customerRepository     = $customerRepository;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->resource               = $resource;
        $this->logger                 = $logger;
        $this->assignTier             = $assignTier;
    }

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order      = $observer->getEvent()->getOrder();
        $customerId = (int) $order->getCustomerId();

        if (!$customerId) {
            return; // guest order — nothing to update
        }

        // Only act when order is freshly completed
        if ($order->getState() !== \Magento\Sales\Model\Order::STATE_COMPLETE) {
            return;
        }

        // Only act once (avoid re-running on subsequent saves of the same order)
        if (!$order->dataHasChangedFor('state')) {
            return;
        }

        try {
            // ── 1. Recalculate lifetime spend ──────────────────────────────
            $totalSpend = $this->calculateLifetimeSpend($customerId);

            // ── 2. Persist lifetime_spend on customer ──────────────────────
            $customer = $this->customerRepository->getById($customerId);
            $customer->setCustomAttribute('lifetime_spend', $totalSpend);
            $this->customerRepository->save($customer);

            // ── 3. Re-assign tier based on new spend ──────────────────────
            $this->assignTier->assignTierBasedOnSpend($customerId, $totalSpend);

            // ── 4. Update discount usage if this order used loyalty discount ─
            $this->updateDiscountUsageIfApplicable($order, $customerId);

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram UpdateLifetimeSpend error: ' . $e->getMessage());
        }
    }

    /**
     * Sum grand_total of all STATE_COMPLETE orders for this customer.
     */
    private function calculateLifetimeSpend(int $customerId): float
    {
        $collection = $this->orderCollectionFactory->create();
        $collection->addFieldToFilter('customer_id', $customerId)
                   ->addFieldToFilter('state', \Magento\Sales\Model\Order::STATE_COMPLETE);

        $total = 0.0;
        foreach ($collection as $completedOrder) {
            $total += (float) $completedOrder->getGrandTotal();
        }

        return $total;
    }

    /**
     * If the order had a loyalty discount applied, increment the customer's
     * loyalty_discount_used attribute and update their total limit if needed.
     */
    private function updateDiscountUsageIfApplicable(\Magento\Sales\Model\Order $order, int $customerId): void
    {
        // Detect loyalty discount: discount_description contains "Program" and "Discount"
        $desc = (string) $order->getDiscountDescription();
        if (!str_contains($desc, 'Program') || !str_contains($desc, 'Discount')) {
            return;
        }

        $discountAmount = abs((float) $order->getDiscountAmount());
        if ($discountAmount <= 0) {
            return;
        }

        try {
            $customer = $this->customerRepository->getById($customerId);
            
            // Get current usage
            $usedAttr = $customer->getCustomAttribute('loyalty_discount_used');
            $currentUsed = ($usedAttr && $usedAttr->getValue()) ? (int) $usedAttr->getValue() : 0;
            
            // Get current limit
            $limitAttr = $customer->getCustomAttribute('loyalty_discount_total_limit');
            $currentLimit = ($limitAttr && $limitAttr->getValue()) ? (int) $limitAttr->getValue() : 0;
            
            // Get tier data to determine the limit
            $tierName = $this->extractTierName($desc);
            $tierLimit = $this->getTierUsageLimit($tierName);
            
            // Update limit if tier has a different limit
            if ($tierLimit > 0 && $tierLimit != $currentLimit) {
                $customer->setCustomAttribute('loyalty_discount_total_limit', $tierLimit);
                $currentLimit = $tierLimit;
            }
            
            // Increment usage
            $newUsed = $currentUsed + 1;
            $customer->setCustomAttribute('loyalty_discount_used', $newUsed);
            
            $this->customerRepository->save($customer);

            $this->logger->info(sprintf(
                'LoyaltyProgram: Usage updated — customer %d, order %d, tier "%s", new usage count %d/%d',
                $customerId,
                $order->getId(),
                $tierName,
                $newUsed,
                $currentLimit
            ));
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram updateDiscountUsageIfApplicable error: ' . $e->getMessage());
        }
    }

    /**
     * Get the usage limit for a specific tier.
     */
    private function getTierUsageLimit(string $tierName): int
    {
        try {
            $connection = $this->resource->getConnection();
            $tierTable = $this->resource->getTableName('loyalty_tiers');

            $select = $connection->select()
                ->from($tierTable, ['usage_limit'])
                ->where('loyalty_tier_name = ?', $tierName)
                ->where('status = ?', 1)
                ->limit(1);

            return (int) $connection->fetchOne($select);
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram getTierUsageLimit error: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Extracts "Gold" from "Gold Program 10% Discount".
     */
    private function extractTierName(string $description): string
    {
        if (preg_match('/^(.+?)\s+Program\s+\d+%\s+Discount$/i', $description, $m)) {
            return trim($m[1]);
        }
        return 'Unknown';
    }
}
