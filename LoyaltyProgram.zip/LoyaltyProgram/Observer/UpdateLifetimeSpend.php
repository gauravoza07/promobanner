<?php
namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Psr\Log\LoggerInterface;

class UpdateLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $orderCollectionFactory;
    protected $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        OrderCollectionFactory $orderCollectionFactory,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $customerId = $order->getCustomerId();

        if (!$customerId) {
            return;
        }

        // Update on order completion
        if ($order->getState() === \Magento\Sales\Model\Order::STATE_COMPLETE) {
            try {
                $orderCollection = $this->orderCollectionFactory->create();
                $orderCollection->addFieldToFilter('customer_id', $customerId)
                    ->addFieldToFilter('state', \Magento\Sales\Model\Order::STATE_COMPLETE);
                
                $totalSpend = 0;
                foreach ($orderCollection as $completedOrder) {
                    $totalSpend += $completedOrder->getGrandTotal();
                }

                $customer = $this->customerRepository->getById($customerId);
                $customer->setCustomAttribute('lifetime_spend', $totalSpend);
                $this->customerRepository->save($customer);

                // Trigger tier assignment after updating spend
                $this->assignCustomerTier($customer, $totalSpend);

            } catch (\Exception $e) {
                $this->logger->error('LoyaltyProgram: Error updating lifetime spend - ' . $e->getMessage());
            }
        }
    }

    private function assignCustomerTier($customer, $lifetimeSpend)
    {
        try {
            $resource = \Magento\Framework\App\ObjectManager::getInstance()->get(\Magento\Framework\App\ResourceConnection::class);
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('loyalty_tiers');

            $select = $connection->select()
                ->from($tableName)
                ->where('min_lifetime_spend <= ?', $lifetimeSpend)
                ->where('status = ?', 1)
                ->order('min_lifetime_spend DESC')
                ->limit(1);

            $tier = $connection->fetchRow($select);

            if ($tier) {
                $customer->setCustomAttribute('custom_customer_attribute', $tier['loyalty_tier_name']);
                $this->customerRepository->save($customer);
            }
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram: Error assigning tier - ' . $e->getMessage());
        }
    }
}