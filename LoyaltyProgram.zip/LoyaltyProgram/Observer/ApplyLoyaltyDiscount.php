<?php
namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\ResourceConnection;
use Magento\Quote\Api\CartRepositoryInterface;
use Psr\Log\LoggerInterface;

class ApplyLoyaltyDiscount implements ObserverInterface
{
    protected $customerSession;
    protected $resource;
    protected $cartRepository;
    protected $logger;

    public function __construct(
        CustomerSession $customerSession,
        ResourceConnection $resource,
        CartRepositoryInterface $cartRepository,
        LoggerInterface $logger
    ) {
        $this->customerSession = $customerSession;
        $this->resource = $resource;
        $this->cartRepository = $cartRepository;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        if (!$this->customerSession->isLoggedIn()) {
            return;
        }

        try {
            $quote = $observer->getEvent()->getQuote();
            $customer = $this->customerSession->getCustomer();
            
            // Get customer tier
            $tierAttribute = $customer->getCustomAttribute('custom_customer_attribute');
            if (!$tierAttribute) {
                return;
            }

            $currentTier = $tierAttribute->getValue();
            
            // Get tier discount info
            $connection = $this->resource->getConnection();
            $tableName = $this->resource->getTableName('loyalty_tiers');

            $select = $connection->select()
                ->from($tableName)
                ->where('loyalty_tier_name = ?', $currentTier)
                ->where('status = ?', 1);

            $tier = $connection->fetchRow($select);

            if (!$tier || $tier['discount_amount'] <= 0) {
                return;
            }

            // Check usage limit
            if (!$this->checkUsageLimit($customer->getId(), $tier)) {
                return;
            }

            // Apply discount
            $discountAmount = $quote->getSubtotal() * ($tier['discount_amount'] / 100);
            
            // Apply discount as a custom discount
            $quote->setLoyaltyDiscount($discountAmount);
            $quote->setLoyaltyTier($currentTier);
            
            // Set discount in the quote
            $quote->setData('loyalty_discount_amount', $discountAmount);
            $quote->setData('loyalty_tier_name', $currentTier);

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram: Error applying discount - ' . $e->getMessage());
        }
    }

    private function checkUsageLimit($customerId, $tier)
    {
        if ($tier['usage_limit'] <= 0) {
            return true; // Unlimited usage
        }

        $connection = $this->resource->getConnection();
        
        // Count completed orders for this customer
        $orderTable = $this->resource->getTableName('sales_order');
        
        $select = $connection->select()
            ->from($orderTable, ['COUNT(*)'])
            ->where('customer_id = ?', $customerId)
            ->where('status IN (?)', ['complete', 'closed']);

        $orderCount = $connection->fetchOne($select);

        return $orderCount < $tier['usage_limit'];
    }
}
