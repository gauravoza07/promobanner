<?php
namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class AssignTier implements ObserverInterface
{
    protected $customerRepository;
    protected $resource;
    protected $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->resource = $resource;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        // This observer will now only handle customer login events
        $customer = $observer->getEvent()->getCustomer();
        
        if (!$customer || !$customer->getId()) {
            return;
        }

        try {
            $lifetimeSpend = $customer->getCustomAttribute('lifetime_spend') 
                ? $customer->getCustomAttribute('lifetime_spend')->getValue() 
                : 0;

            $this->assignTierBasedOnSpend($customer, $lifetimeSpend);

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram: Error in AssignTier - ' . $e->getMessage());
        }
    }

    private function assignTierBasedOnSpend($customer, $lifetimeSpend)
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('loyalty_tiers');

        $select = $connection->select()
            ->from($tableName)
            ->where('min_lifetime_spend <= ?', $lifetimeSpend)
            ->where('status = ?', 1)
            ->order('min_lifetime_spend DESC')
            ->limit(1);

        $tier = $connection->fetchRow($select);

        if ($tier) {
            $customerEntity = $this->customerRepository->getById($customer->getId());
            $customerEntity->setCustomAttribute('custom_customer_attribute', $tier['loyalty_tier_name']);
            $this->customerRepository->save($customerEntity);
        }
    }
}