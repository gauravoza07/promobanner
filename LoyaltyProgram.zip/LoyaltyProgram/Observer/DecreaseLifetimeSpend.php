<?php
/**
 * DecreaseLifetimeSpend observer.
 *
 * Fires: sales_order_creditmemo_save_after
 *
 * When a refund (credit memo) is issued:
 *  1. Subtracts refunded grand total from the customer's lifetime spend.
 *  2. Re-assigns the tier (customer may drop to a lower tier after refund).
 *  3. Decrements the discount usage count if the original order used a loyalty discount.
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class DecreaseLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $resource;
    protected $logger;
    protected $assignTier;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        LoggerInterface $logger,
        AssignTier $assignTier
    ) {
        $this->customerRepository = $customerRepository;
        $this->resource           = $resource;
        $this->logger             = $logger;
        $this->assignTier         = $assignTier;
    }

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Sales\Model\Order\Creditmemo $creditmemo */
        $creditmemo = $observer->getEvent()->getCreditmemo();
        $order      = $creditmemo->getOrder();
        $customerId = (int) $order->getCustomerId();

        if (!$customerId) {
            return;
        }

        try {
            $customer     = $this->customerRepository->getById($customerId);
            $attr         = $customer->getCustomAttribute('lifetime_spend');
            $currentSpend = $attr ? (float) $attr->getValue() : 0.0;

            $refundAmount = (float) $creditmemo->getGrandTotal();
            $newSpend     = max(0.0, $currentSpend - $refundAmount);

            // ── 1. Update lifetime spend ──────────────────────────────────
            $customer->setCustomAttribute('lifetime_spend', $newSpend);
            $this->customerRepository->save($customer);

            // ── 2. Re-assign tier ─────────────────────────────────────────
            $this->assignTier->assignTierBasedOnSpend($customerId, $newSpend);

            // ── 3. Decrease discount usage if this order had a loyalty discount ────
            $this->decreaseDiscountUsageIfApplicable($order, $customerId);

            $this->logger->info(sprintf(
                'LoyaltyProgram: Refund processed for customer %d. Spend %.2f → %.2f',
                $customerId,
                $currentSpend,
                $newSpend
            ));
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram DecreaseLifetimeSpend error: ' . $e->getMessage());
        }
    }

    /**
     * Decrements the customer's discount usage count if the refunded order
     * had a loyalty discount applied.
     */
    private function decreaseDiscountUsageIfApplicable(\Magento\Sales\Model\Order $order, int $customerId): void
    {
        // Detect loyalty discount: discount_description contains "Program" and "Discount"
        $desc = (string) $order->getDiscountDescription();
        if (!str_contains($desc, 'Program') || !str_contains($desc, 'Discount')) {
            return;
        }

        try {
            $customer = $this->customerRepository->getById($customerId);
            
            // Get current usage
            $usedAttr = $customer->getCustomAttribute('loyalty_discount_used');
            $currentUsed = ($usedAttr && $usedAttr->getValue()) ? (int) $usedAttr->getValue() : 0;
            
            if ($currentUsed > 0) {
                // Decrement usage
                $newUsed = $currentUsed - 1;
                $customer->setCustomAttribute('loyalty_discount_used', $newUsed);
                $this->customerRepository->save($customer);

                $this->logger->info(sprintf(
                    'LoyaltyProgram: Usage decreased for customer %d due to refund for order %d. New usage count: %d',
                    $customerId,
                    $order->getId(),
                    $newUsed
                ));
            }
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram decreaseDiscountUsageIfApplicable error: ' . $e->getMessage());
        }
    }
}
