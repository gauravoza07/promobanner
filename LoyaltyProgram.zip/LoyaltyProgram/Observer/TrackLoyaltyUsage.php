<?php
namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class TrackLoyaltyUsage implements ObserverInterface
{
    protected $resource;
    protected $logger;

    public function __construct(
        ResourceConnection $resource,
        LoggerInterface $logger
    ) {
        $this->resource = $resource;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        
        if (!$order->getCustomerId()) {
            return;
        }

        try {
            $loyaltyDiscount = $order->getData('loyalty_discount_amount');
            $loyaltyTier = $order->getData('loyalty_tier_name');
            
            if (!$loyaltyDiscount || !$loyaltyTier) {
                return;
            }

            $connection = $this->resource->getConnection();
            
            // Get tier ID
            $tierTable = $this->resource->getTableName('loyalty_tiers');
            $select = $connection->select()
                ->from($tierTable, ['loyalty_tier_id'])
                ->where('loyalty_tier_name = ?', $loyaltyTier);
            
            $tierId = $connection->fetchOne($select);
            
            if (!$tierId) {
                return;
            }

            // Insert usage record
            $usageTable = $this->resource->getTableName('loyalty_usage');
            $connection->insert($usageTable, [
                'customer_id' => $order->getCustomerId(),
                'loyalty_tier_id' => $tierId,
                'order_id' => $order->getId(),
                'discount_amount' => $loyaltyDiscount,
                'created_at' => date('Y-m-d H:i:s')
            ]);

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram: Error tracking usage - ' . $e->getMessage());
        }
    }
}
