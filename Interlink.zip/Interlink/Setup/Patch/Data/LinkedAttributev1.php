<?php

namespace Icreative\Interlink\Setup\Patch\Data;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Catalog\Model\Product;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;

class LinkedAttributev1 implements DataPatchInterface, PatchRevertableInterface
{
    private $eavSetupFactory;
    private $moduleDataSetup;

    public function __construct(
        EavSetupFactory $eavSetupFactory,
        ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->moduleDataSetup = $moduleDataSetup;
    }

    public function apply()
    {
        $this->moduleDataSetup->getConnection()->startSetup();

        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);

        $eavSetup->removeAttribute(Product::ENTITY, 'linked_skus');

        $eavSetup->addAttribute(
            Product::ENTITY,    
            'linked_skus',       
            [                    
                'type'     => 'varchar',          
                'label'    => 'Linked Products',  
                'input'    => 'text',             
                'note'     => 'Enter comma-separated SKUs of linked products. Example: SKU001, SKU002',
                'required' => false,               
                'default'  => '',                  
                'global'   => ScopedAttributeInterface::SCOPE_GLOBAL,  
                'visible'              => true,    
                'user_defined'         => true,    
                'searchable'           => false,   
                'filterable'           => false,   
                'comparable'          => false,    
                'visible_on_front'     => false,    
                'used_in_product_listing' => false, 
                'group'      => 'Product Details', 
                'sort_order' => 100,               
            ]
        );

        $this->moduleDataSetup->getConnection()->endSetup();
    }

    public static function getDependencies()
    {
        return [];
    }

    public function getAliases()
    {
        return [];
    }

    public function revert()
    {
        $this->moduleDataSetup->getConnection()->startSetup();

        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);
        
        $eavSetup->removeAttribute(Product::ENTITY, 'linked_skus');

        $this->moduleDataSetup->getConnection()->endSetup();
    }
}
