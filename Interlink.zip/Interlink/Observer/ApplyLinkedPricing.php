<?php

namespace Icreative\Interlink\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Icreative\Interlink\Helper\LinkedProducts;
use Icreative\Interlink\Model\TierPricing;
use Psr\Log\LoggerInterface;

class ApplyLinkedPricing implements ObserverInterface
{
    private $linkedProductsHelper;   
    private $tierPricingModel;
    private $logger;

    public function __construct(
        LinkedProducts $linkedProductsHelper,
        TierPricing $tierPricingModel,
        LoggerInterface $logger
    ) {
        $this->linkedProductsHelper = $linkedProductsHelper;
        $this->tierPricingModel     = $tierPricingModel;
        $this->logger               = $logger;
    }
   
    public function execute(Observer $observer)
    {
        try {
            $cartQuote = $observer->getEvent()->getQuote();
            
            if (!$cartQuote || !$cartQuote->getId()) {
                return;
            }
            
            $linkedProductGroups = $this->linkedProductsHelper->getLinkedItemsInCart($cartQuote);

            if (empty($linkedProductGroups)) {
                return;
            }

            foreach ($linkedProductGroups as $currentGroup) {
                $this->applyNewPricesToGroup($currentGroup);
            }

        } catch (\Exception $error) {
            $this->logger->error('[Interlink] Error in ApplyLinkedPricing: ' . $error->getMessage());
        }
    }

    private function applyNewPricesToGroup(array $linkedProductGroup)
    {
        $combinedQuantity = $this->linkedProductsHelper->getGroupTotalQty($linkedProductGroup);

        $this->logger->info('[Interlink] Processing linked group. Total combined qty: ' . $combinedQuantity);

        foreach ($linkedProductGroup as $cartItem) {
            $product = $cartItem->getProduct();
            
            $productId = $product->getId();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $fullProduct = $objectManager->get(\Magento\Catalog\Api\ProductRepositoryInterface::class)->getById($productId);

            $newTierPrice = $this->tierPricingModel->getApplicableTierPrice(
                $fullProduct,
                $combinedQuantity
            );

            $cartItem->setCustomPrice($newTierPrice);
            $cartItem->setOriginalCustomPrice($newTierPrice);
            $cartItem->getProduct()->setIsSuperMode(true);

            $this->logger->info(sprintf(
                '[Interlink] Applied pricing | SKU: %s | Item Qty: %s | Combined Qty: %s | Applied Price: %s',
                $product->getSku(),
                $cartItem->getQty(),
                $combinedQuantity,
                $newTierPrice
            ));
        }
    }
}
