<?php
namespace Icreative\Interlink\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Icreative\Interlink\Helper\LinkedProducts;
use Psr\Log\LoggerInterface;

class DebugLinkedProducts implements ObserverInterface
{
    private $linkedProductsHelper;
    private $logger;

    public function __construct(
        LinkedProducts $linkedProductsHelper,
        LoggerInterface $logger
    ) {
        $this->linkedProductsHelper = $linkedProductsHelper;
        $this->logger               = $logger;
    }

    public function execute(Observer $observer)
    {
        try {
            $cart = $observer->getEvent()->getCart();

            if (!$cart) {
                return;
            }

            $quote = $cart->getQuote();

            if (!$quote || !$quote->getId()) {
                return;
            }

            $cartItems = $quote->getAllVisibleItems();
            
            $debugMessage = "\n======== INTERLINK DEBUG ========\n";
            $debugMessage .= "Cart items found: " . count($cartItems) . "\n";

            foreach ($cartItems as $cartItem) {
                $product = $cartItem->getProduct();
                
                $productId = $product->getId();
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $fullProduct = $objectManager->get(\Magento\Catalog\Api\ProductRepositoryInterface::class)->getById($productId);
                
                $linkedSkus = $this->linkedProductsHelper->getLinkedSkus($fullProduct);
                
                $rawLinkedSkus = $fullProduct->getData('linked_skus');
                $customAttribute = $fullProduct->getCustomAttribute('linked_skus');
                $customValue = $customAttribute ? $customAttribute->getValue() : 'NULL';

                $debugMessage .= sprintf(
                    "SKU: %-15s | Qty: %s | linked_skus: [%s]\n",
                    $product->getSku(),
                    $cartItem->getQty(),
                    implode(', ', $linkedSkus) ?: 'none'
                );
                
                $debugMessage .= sprintf(
                    "Raw data: '%s' | Custom attribute: '%s'\n",
                    $rawLinkedSkus ?: 'NULL',
                    $customValue
                );
            }

            $linkedGroups = $this->linkedProductsHelper->getLinkedItemsInCart($quote);
            $debugMessage .= "\nLinked groups detected: " . count($linkedGroups) . "\n";

            foreach ($linkedGroups as $groupNumber => $group) {
                $totalQuantity = $this->linkedProductsHelper->getGroupTotalQty($group);
                $debugMessage .= "  Group #" . ($groupNumber + 1) . " (combined qty: $totalQuantity):\n";

                foreach ($group as $groupItem) {
                    $debugMessage .= "    - " . $groupItem->getProduct()->getSku() . " (qty: " . $groupItem->getQty() . ")\n";
                }
            }

            $debugMessage .= "=================================\n";

            $this->logger->info($debugMessage);

        } catch (\Exception $error) {
            $this->logger->error('[Interlink] DebugLinkedProducts error: ' . $error->getMessage());
        }
    }
}
