<?php

namespace Icreative\Interlink\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Catalog\Model\Product;

class LinkedProducts extends AbstractHelper
{
    public function getLinkedSkus(Product $product)
    {
        $linkedSkusValue = $product->getData('linked_skus');

        if (empty($linkedSkusValue) || !is_string($linkedSkusValue)) {
            return [];
        }

        $skuArray = explode(',', $linkedSkusValue);
        $cleanSkus = [];

        foreach ($skuArray as $sku) {
            $cleanSku = trim($sku);
            if (!empty($cleanSku)) {
                $cleanSkus[] = $cleanSku;
            }
        }

        return $cleanSkus;
    }

    public function areProductsLinked(Product $product1, Product $product2)
    {
        $product1Links = $this->getLinkedSkus($product1);
        $product2Links = $this->getLinkedSkus($product2);

        $sku1 = $product1->getSku();
        $sku2 = $product2->getSku();

        if (in_array($sku2, $product1Links)) {
            return true;
        }

        if (in_array($sku1, $product2Links)) {
            return true;
        }

        return false;
    }

    public function getLinkedItemsInCart($quote)
    {
        $cartItems = $quote->getAllVisibleItems();
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productRepository = $objectManager->get(\Magento\Catalog\Api\ProductRepositoryInterface::class);

        $linkedGroups = [];
        $alreadyProcessedItems = [];

        foreach ($cartItems as $firstItem) {
            if (in_array($firstItem->getId(), $alreadyProcessedItems)) {
                continue;
            }

            $currentGroup = [$firstItem];
            $alreadyProcessedItems[] = $firstItem->getId();

            foreach ($cartItems as $secondItem) {
                if ($firstItem->getId() === $secondItem->getId() || 
                    in_array($secondItem->getId(), $alreadyProcessedItems)) {
                    continue;
                }

                $firstProduct = $productRepository->getById($firstItem->getProduct()->getId());
                $secondProduct = $productRepository->getById($secondItem->getProduct()->getId());

                if ($this->areProductsLinked($firstProduct, $secondProduct)) {
                    $currentGroup[] = $secondItem;
                    $alreadyProcessedItems[] = $secondItem->getId();
                }
            }

            if (count($currentGroup) > 1) {
                $linkedGroups[] = $currentGroup;
            }
        }

        return $linkedGroups;
    }

    public function getGroupTotalQty(array $linkedItems)
    {
        $totalQuantity = 0;
        
        foreach ($linkedItems as $item) {
            $totalQuantity += (float) $item->getQty();
        }
        
        return $totalQuantity;
    }
}
