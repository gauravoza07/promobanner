<?php
/**
 * UpdateLifetimeSpend observer.
 *
 * Fires: sales_order_save_after
 *
 * When an order reaches STATE_COMPLETE:
 *  1. Re-calculates the customer's total lifetime spend from all complete orders.
 *  2. Saves the updated lifetime_spend customer attribute.
 *  3. Re-assigns the loyalty tier via AssignTier.
 *  4. Increments loyalty_discount_used if this order carried a loyalty discount,
 *     but ONLY if remaining quota > 0 (or limit is 0 = unlimited).
 *     Once all uses are exhausted the counter stays at the limit and no more
 *     discounts are issued.
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Psr\Log\LoggerInterface;

class UpdateLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $orderCollectionFactory;
    protected $resource;
    protected $logger;
    protected $assignTier;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        OrderCollectionFactory $orderCollectionFactory,
        ResourceConnection $resource,
        LoggerInterface $logger,
        AssignTier $assignTier
    ) {
        $this->customerRepository     = $customerRepository;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->resource               = $resource;
        $this->logger                 = $logger;
        $this->assignTier             = $assignTier;
    }

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order      = $observer->getEvent()->getOrder();
        $customerId = (int) $order->getCustomerId();

        if (!$customerId) {
            return;
        }

        if ($order->getState() !== \Magento\Sales\Model\Order::STATE_COMPLETE) {
            return;
        }

        if (!$order->dataHasChangedFor('state')) {
            return;
        }

        try {
            // ── 1. Recalculate lifetime spend ──────────────────────────────
            $totalSpend = $this->calculateLifetimeSpend($customerId);

            // ── 2. Persist lifetime_spend on customer ──────────────────────
            $customer = $this->customerRepository->getById($customerId);
            $customer->setCustomAttribute('lifetime_spend', $totalSpend);
            $this->customerRepository->save($customer);

            // ── 3. Re-assign tier (may also reset usage on tier change) ───
            $this->assignTier->assignTierBasedOnSpend($customerId, $totalSpend);

            // ── 4. Increment discount usage counter if applicable ──────────
            $this->incrementUsageIfApplicable($order, $customerId);

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram UpdateLifetimeSpend error: ' . $e->getMessage());
        }
    }

    private function calculateLifetimeSpend(int $customerId): float
    {
        $collection = $this->orderCollectionFactory->create();
        $collection->addFieldToFilter('customer_id', $customerId)
                   ->addFieldToFilter('state', \Magento\Sales\Model\Order::STATE_COMPLETE);

        $total = 0.0;
        foreach ($collection as $completedOrder) {
            $total += (float) $completedOrder->getGrandTotal();
        }

        return $total;
    }

    /**
     * Increments loyalty_discount_used on the customer when a loyalty
     * discount was applied to this completed order.
     * Idempotent: skips if discount_used already accounts for this order
     * (we store the order ID in a helper attribute to avoid double-counting).
     */
    private function incrementUsageIfApplicable(\Magento\Sales\Model\Order $order, int $customerId): void
    {
        // Detect loyalty discount via discount_description
        $desc = (string) $order->getDiscountDescription();
        if (!str_contains($desc, 'Program') || !str_contains($desc, 'Discount')) {
            return;
        }

        $discountAmount = abs((float) $order->getDiscountAmount());
        if ($discountAmount <= 0) {
            return;
        }

        try {
            $customer = $this->customerRepository->getById($customerId);

            // Idempotency: track last order id that incremented usage
            $lastOrderAttr = $customer->getCustomAttribute('loyalty_last_discounted_order');
            $lastOrderId   = $lastOrderAttr ? (int) $lastOrderAttr->getValue() : 0;
            if ($lastOrderId === (int) $order->getId()) {
                $this->logger->info(sprintf(
                    'LoyaltyProgram: Usage already recorded for order %d, skipping.',
                    $order->getId()
                ));
                return;
            }

            $usedAttr  = $customer->getCustomAttribute('loyalty_discount_used');
            $limitAttr = $customer->getCustomAttribute('loyalty_discount_total_limit');
            $used      = $usedAttr  ? (int) $usedAttr->getValue()  : 0;
            $limit     = $limitAttr ? (int) $limitAttr->getValue() : 0;

            // If limit is 0 it means unlimited — always increment
            // If limit > 0, only increment up to the limit (discount was already
            // gate-kept in CustomDiscount::isWithinUsageLimit, so here we just record)
            $newUsed = $used + 1;
            if ($limit > 0) {
                $newUsed = min($newUsed, $limit);
            }

            $customer->setCustomAttribute('loyalty_discount_used', $newUsed);
            $customer->setCustomAttribute('loyalty_last_discounted_order', (int) $order->getId());
            $this->customerRepository->save($customer);

            $this->logger->info(sprintf(
                'LoyaltyProgram: Usage incremented for customer %d, order %d. Used: %d / Limit: %d',
                $customerId,
                $order->getId(),
                $newUsed,
                $limit
            ));

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram incrementUsageIfApplicable error: ' . $e->getMessage());
        }
    }
}
