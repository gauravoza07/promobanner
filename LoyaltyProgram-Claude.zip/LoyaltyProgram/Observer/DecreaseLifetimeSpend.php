<?php
/**
 * DecreaseLifetimeSpend observer.
 *
 * Fires: sales_order_creditmemo_save_after
 *
 * When a refund (credit memo) is issued:
 *  1. Subtracts the refunded grand total from the customer's lifetime spend.
 *  2. Re-assigns the tier (customer may drop to a lower tier after refund).
 *  3. Decrements loyalty_discount_used if the refunded order used a loyalty
 *     discount (restores one usage slot).
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class DecreaseLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $resource;
    protected $logger;
    protected $assignTier;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        LoggerInterface $logger,
        AssignTier $assignTier
    ) {
        $this->customerRepository = $customerRepository;
        $this->resource           = $resource;
        $this->logger             = $logger;
        $this->assignTier         = $assignTier;
    }

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Sales\Model\Order\Creditmemo $creditmemo */
        $creditmemo = $observer->getEvent()->getCreditmemo();
        $order      = $creditmemo->getOrder();
        $customerId = (int) $order->getCustomerId();

        if (!$customerId) {
            return;
        }

        try {
            $customer     = $this->customerRepository->getById($customerId);
            $attr         = $customer->getCustomAttribute('lifetime_spend');
            $currentSpend = $attr ? (float) $attr->getValue() : 0.0;

            $refundAmount = (float) $creditmemo->getGrandTotal();
            $newSpend     = max(0.0, $currentSpend - $refundAmount);

            // ── 1. Update lifetime spend ──────────────────────────────────
            $customer->setCustomAttribute('lifetime_spend', $newSpend);
            $this->customerRepository->save($customer);

            // ── 2. Re-assign tier ─────────────────────────────────────────
            $this->assignTier->assignTierBasedOnSpend($customerId, $newSpend);

            // ── 3. Restore one usage slot if refunded order used discount ──
            $this->decrementUsageIfApplicable($order, $customerId);

            $this->logger->info(sprintf(
                'LoyaltyProgram: Refund processed for customer %d. Spend %.2f → %.2f',
                $customerId,
                $currentSpend,
                $newSpend
            ));
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram DecreaseLifetimeSpend error: ' . $e->getMessage());
        }
    }

    private function decrementUsageIfApplicable(\Magento\Sales\Model\Order $order, int $customerId): void
    {
        $desc = (string) $order->getDiscountDescription();
        if (!str_contains($desc, 'Program') || !str_contains($desc, 'Discount')) {
            return;
        }

        $discountAmount = abs((float) $order->getDiscountAmount());
        if ($discountAmount <= 0) {
            return;
        }

        try {
            $customer  = $this->customerRepository->getById($customerId);
            $usedAttr  = $customer->getCustomAttribute('loyalty_discount_used');
            $used      = $usedAttr ? (int) $usedAttr->getValue() : 0;
            $newUsed   = max(0, $used - 1);

            $customer->setCustomAttribute('loyalty_discount_used', $newUsed);

            // Clear idempotency order reference if it matches this refunded order
            $lastOrderAttr = $customer->getCustomAttribute('loyalty_last_discounted_order');
            if ($lastOrderAttr && (int) $lastOrderAttr->getValue() === (int) $order->getId()) {
                $customer->setCustomAttribute('loyalty_last_discounted_order', 0);
            }

            $this->customerRepository->save($customer);

            $this->logger->info(sprintf(
                'LoyaltyProgram: Usage decremented for customer %d (refund of order %d). Used: %d → %d',
                $customerId,
                $order->getId(),
                $used,
                $newUsed
            ));
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram decrementUsageIfApplicable error: ' . $e->getMessage());
        }
    }
}
