<?php
/**
 * AssignTier observer.
 *
 * Fires on:
 *  - customer_customer_authenticated  (every login)
 *  - customer_register_success        (new registration)
 *
 * Looks up the highest loyalty tier whose min_lifetime_spend the customer
 * has met and saves it as the 'custom_customer_attribute' on the customer.
 *
 * Also syncs loyalty_discount_total_limit from the matched tier row and
 * resets loyalty_discount_used to 0 whenever the tier CHANGES (upgrade/downgrade).
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class AssignTier implements ObserverInterface
{
    protected $customerRepository;
    protected $resource;
    protected $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->resource           = $resource;
        $this->logger             = $logger;
    }

    public function execute(Observer $observer): void
    {
        $customer = $observer->getEvent()->getCustomer()
            ?? $observer->getEvent()->getData('customer');

        if (!$customer || !$customer->getId()) {
            return;
        }

        try {
            $lifetimeSpend = 0;
            $attr = $customer->getCustomAttribute('lifetime_spend');
            if ($attr) {
                $lifetimeSpend = (float) $attr->getValue();
            }

            $this->assignTierBasedOnSpend($customer->getId(), $lifetimeSpend);
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram AssignTier error: ' . $e->getMessage());
        }
    }

    /**
     * Finds the best matching tier and persists it on the customer.
     * - Sets custom_customer_attribute to tier name (or '' if no match).
     * - Syncs loyalty_discount_total_limit from tier's usage_limit.
     * - Resets loyalty_discount_used to 0 only when the tier name changes.
     *
     * @param int   $customerId
     * @param float $lifetimeSpend
     */
    public function assignTierBasedOnSpend(int $customerId, float $lifetimeSpend): void
    {
        $connection = $this->resource->getConnection();
        $tierTable  = $this->resource->getTableName('loyalty_tiers');

        $select = $connection->select()
            ->from($tierTable)
            ->where('min_lifetime_spend <= ?', $lifetimeSpend)
            ->where('status = ?', 1)
            ->order('min_lifetime_spend DESC')
            ->limit(1);

        $tier     = $connection->fetchRow($select);
        $customer = $this->customerRepository->getById($customerId);

        $newTierName  = $tier ? $tier['loyalty_tier_name'] : '';
        $usageLimit   = $tier ? (int) $tier['usage_limit'] : 0;

        // Detect tier change to reset usage counter
        $oldTierAttr = $customer->getCustomAttribute('custom_customer_attribute');
        $oldTierName = $oldTierAttr ? (string) $oldTierAttr->getValue() : '';

        $tierChanged = ($oldTierName !== $newTierName);

        $customer->setCustomAttribute('custom_customer_attribute', $newTierName);
        $customer->setCustomAttribute('loyalty_discount_total_limit', $usageLimit);

        // Reset used count on tier change (upgrade or downgrade gets fresh quota)
        if ($tierChanged) {
            $customer->setCustomAttribute('loyalty_discount_used', 0);
            $this->logger->info(sprintf(
                'LoyaltyProgram: Tier changed for customer %d: "%s" → "%s". Usage reset.',
                $customerId,
                $oldTierName,
                $newTierName
            ));
        }

        $this->customerRepository->save($customer);

        if ($tier) {
            $this->logger->info(sprintf(
                'LoyaltyProgram: Customer %d assigned to tier "%s" (spend: %.2f, limit: %d)',
                $customerId,
                $tier['loyalty_tier_name'],
                $lifetimeSpend,
                $usageLimit
            ));
        }
    }
}
