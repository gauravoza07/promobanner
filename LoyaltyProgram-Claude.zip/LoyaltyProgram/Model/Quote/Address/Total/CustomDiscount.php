<?php
/**
 * CustomDiscount total collector.
 *
 * Applies the loyalty tier discount at quote collection time.
 * Usage is gate-kept by reading loyalty_discount_used vs
 * loyalty_discount_total_limit from the customer's custom attributes —
 * no separate DB table required.
 *
 * fetch() returns the segment used by Knockout JS to render the
 * cart/checkout discount row with the tier label.
 */

namespace Icreative\LoyaltyProgram\Model\Quote\Address\Total;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Total;
use Psr\Log\LoggerInterface;

class CustomDiscount extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
    protected $priceCurrency;
    protected $customerSession;
    protected $resource;
    protected $customerRepository;
    protected $logger;

    /** @var array|null|false */
    private $cachedTierData = null;

    public function __construct(
        PriceCurrencyInterface $priceCurrency,
        CustomerSession $customerSession,
        ResourceConnection $resource,
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->priceCurrency      = $priceCurrency;
        $this->customerSession    = $customerSession;
        $this->resource           = $resource;
        $this->customerRepository = $customerRepository;
        $this->logger             = $logger;
        $this->setCode('customdiscount');
    }

    public function collect(
        Quote $quote,
        ShippingAssignmentInterface $shippingAssignment,
        Total $total
    ): self {
        parent::collect($quote, $shippingAssignment, $total);

        $total->setTotalAmount('customdiscount', 0);
        $total->setBaseTotalAmount('customdiscount', 0);
        $this->cachedTierData = null;

        if (!count($shippingAssignment->getItems())) {
            return $this;
        }

        try {
            $customerId = $this->resolveCustomerId($quote);
            if (!$customerId) {
                return $this;
            }

            $tierData = $this->getCustomerTierData($customerId);
            if (!$tierData) {
                return $this;
            }

            $discountAmount = $this->computeDiscount($quote, $tierData, $customerId);

            $this->logger->info('[LoyaltyProgram] Discount calculation', [
                'customer_id'    => $customerId,
                'tier'           => $tierData['loyalty_tier_name'] ?? '',
                'discount_pct'   => $tierData['discount_amount'] ?? 0,
                'discount_amount' => $discountAmount,
                'quote_subtotal'  => $quote->getSubtotal(),
            ]);

            if ($discountAmount < 0) {
                $total->addTotalAmount('customdiscount', $discountAmount);
                $total->addBaseTotalAmount('customdiscount', $discountAmount);
                $quote->setData('loyalty_discount_amount', $discountAmount);
                $quote->setData('loyalty_discount_label', $this->buildLabel($tierData));
            } else {
                $quote->setData('loyalty_discount_amount', 0);
                $quote->setData('loyalty_discount_label', '');
            }
        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] collect() exception: ' . $e->getMessage());
        }

        return $this;
    }

    /**
     * Called by Magento to build the totals segment used by KO templates.
     * Must always return an array with code/title/value so the JS component
     * can render — even when zero (isDisplayed() in JS guards the render).
     */
    public function fetch(Quote $quote, Total $total): array
    {
        $amount = (float) $total->getTotalAmount('customdiscount');

        if ($amount >= 0) {
            $amount = (float) $quote->getData('loyalty_discount_amount');
        }

        $label = (string) $quote->getData('loyalty_discount_label');

        // Rebuild label from tier data if quote data was not persisted
        if (!$label && $amount < 0) {
            $customerId = $this->resolveCustomerId($quote);
            if ($customerId) {
                $tierData = $this->getCustomerTierData($customerId);
                $label    = $tierData ? $this->buildLabel($tierData) : '';
            }
        }

        if (!$label) {
            $label = (string) __('Loyalty Discount');
        }

        // Return an entry regardless — JS isDisplayed() checks value < 0
        return [
            'code'  => $this->getCode(),
            'title' => $label,
            'value' => $amount,
        ];
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    private function resolveCustomerId(Quote $quote): int
    {
        $id = (int) $quote->getCustomerId();
        if ($id) {
            return $id;
        }
        try {
            $id = (int) $this->customerSession->getCustomerId();
        } catch (\Exception $e) {
            // session not available in CLI / API context
        }
        return $id;
    }

    private function getCustomerTierData(int $customerId)
    {
        if ($this->cachedTierData !== null) {
            return $this->cachedTierData;
        }

        $this->cachedTierData = false;

        try {
            $customer = $this->customerRepository->getById($customerId);
            $tierName = $this->getAssignedTierName($customer);
            if ($tierName) {
                $this->cachedTierData = $this->fetchTierByName($tierName);
            }
            if (!$this->cachedTierData) {
                $this->cachedTierData = $this->fetchTierByLifetimeSpend($customer);
            }
        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] getCustomerTierData() exception: ' . $e->getMessage());
        }

        return $this->cachedTierData;
    }

    private function getAssignedTierName($customer): ?string
    {
        $attr = $customer->getCustomAttribute('custom_customer_attribute');
        return ($attr && $attr->getValue()) ? trim((string) $attr->getValue()) : null;
    }

    private function fetchTierByName(string $tierName)
    {
        $conn  = $this->resource->getConnection();
        $table = $this->resource->getTableName('loyalty_tiers');
        $row   = $conn->fetchRow(
            $conn->select()->from($table)
                ->where('loyalty_tier_name = ?', $tierName)
                ->where('status = ?', 1)
                ->limit(1)
        );
        return $row ?: false;
    }

    private function fetchTierByLifetimeSpend($customer)
    {
        $attr          = $customer->getCustomAttribute('lifetime_spend');
        $lifetimeSpend = $attr ? (float) $attr->getValue() : 0.0;
        if ($lifetimeSpend <= 0) {
            return false;
        }
        $conn  = $this->resource->getConnection();
        $table = $this->resource->getTableName('loyalty_tiers');
        $row   = $conn->fetchRow(
            $conn->select()->from($table)
                ->where('min_lifetime_spend <= ?', $lifetimeSpend)
                ->where('status = ?', 1)
                ->order('min_lifetime_spend DESC')
                ->limit(1)
        );
        return $row ?: false;
    }

    private function computeDiscount(Quote $quote, array $tierData, int $customerId): float
    {
        $pct = (float) ($tierData['discount_amount'] ?? 0);
        if ($pct <= 0) {
            return 0.0;
        }

        $subtotal = (float) $quote->getSubtotal();
        if ($subtotal <= 0) {
            return 0.0;
        }

        if (!$this->isWithinUsageLimit($tierData, $customerId)) {
            $this->logger->info('[LoyaltyProgram] Usage limit reached — no discount applied.', [
                'customer_id' => $customerId,
            ]);
            return 0.0;
        }

        return -(round($subtotal * $pct / 100, 4));
    }

    /**
     * Checks loyalty_discount_used < loyalty_discount_total_limit on the customer.
     * Returns true (allow discount) when:
     *   - usage_limit in the tier row is 0 (unlimited), OR
     *   - the customer's used count is still below their limit attribute.
     */
    private function isWithinUsageLimit(array $tierData, int $customerId): bool
    {
        $tierLimit = (int) ($tierData['usage_limit'] ?? 0);
        if ($tierLimit <= 0) {
            return true; // unlimited
        }

        try {
            $customer  = $this->customerRepository->getById($customerId);
            $usedAttr  = $customer->getCustomAttribute('loyalty_discount_used');
            $limitAttr = $customer->getCustomAttribute('loyalty_discount_total_limit');

            $used  = $usedAttr  ? (int) $usedAttr->getValue()  : 0;
            $limit = $limitAttr ? (int) $limitAttr->getValue() : $tierLimit;

            // Fallback to tier row limit when attribute not yet set
            if ($limit <= 0) {
                $limit = $tierLimit;
            }

            return $used < $limit;

        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] isWithinUsageLimit() exception: ' . $e->getMessage());
            return false;
        }
    }

    private function buildLabel(array $tierData): string
    {
        if (!empty($tierData['loyalty_tier_name']) && isset($tierData['discount_amount'])) {
            return (string) __(
                '%1 Program %2% Discount',
                $tierData['loyalty_tier_name'],
                (int) $tierData['discount_amount']
            );
        }
        return (string) __('Loyalty Discount');
    }
}
