/**
 * Checkout sidebar + cart totals Knockout component for the loyalty discount row.
 *
 * Reads the 'customdiscount' segment that PHP CustomDiscount::fetch() pushes
 * into the totals JSON.  The segment always contains:
 *   { code: 'customdiscount', title: 'Gold Program 10% Discount', value: -15.00 }
 *
 * isDisplayed() returns false when value === 0 so no phantom row appears.
 */
define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/totals'
], function (Component, totals) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Icreative_LoyaltyProgram/cart/totals/custom-discount'
        },

        /**
         * @return {Object|null}
         */
        getDiscountSegment: function () {
            return totals.getSegment('customdiscount');
        },

        /**
         * @return {Number}  negative when discount is active, 0 otherwise
         */
        getPureValue: function () {
            var segment = this.getDiscountSegment();
            return segment ? parseFloat(segment.value) : 0;
        },

        /**
         * Only show when value is strictly negative.
         * @return {Boolean}
         */
        isDisplayed: function () {
            return this.getPureValue() < 0;
        },

        /**
         * Returns the tier label e.g. "Gold Program 10% Discount".
         * Falls back to a generic string so the <span> never renders blank.
         * @return {String}
         */
        getTitle: function () {
            var segment = this.getDiscountSegment();
            if (segment && segment.title) {
                return segment.title;
            }
            return 'Loyalty Discount';
        },

        /**
         * Formatted price string e.g. "-₹15.00".
         * @return {String}
         */
        getValue: function () {
            return this.getFormattedPrice(this.getPureValue());
        }
    });
});
