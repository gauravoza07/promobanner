/**
 * Cart page totals component — extends the checkout summary component
 * so both contexts share identical logic.  isDisplayed is kept true
 * here; the parent's isDisplayed() already returns false when value === 0.
 */
define([
    'Icreative_LoyaltyProgram/js/view/checkout/summary/custom-discount'
], function (Component) {
    'use strict';

    return Component.extend({
        defaults: {
            // Cart page uses the same template as checkout sidebar
            template: 'Icreative_LoyaltyProgram/cart/totals/custom-discount'
        }
    });
});
