<?php
/**
 * Data patch: add three custom customer EAV attributes for loyalty usage tracking.
 *
 *  loyalty_discount_used              — count of orders that used the discount
 *  loyalty_discount_total_limit       — total allowed uses copied from tier on assignment
 *  loyalty_last_discounted_order      — last order_id that incremented usage (idempotency)
 *
 * Depends on CustomerAttribute (which creates custom_customer_attribute + lifetime_spend).
 */

namespace Icreative\LoyaltyProgram\Setup\Patch\Data;

use Magento\Customer\Model\ResourceModel\Attribute as AttributeResource;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;

class AddLoyaltyDiscountAttributes implements DataPatchInterface
{
    private ModuleDataSetupInterface $moduleDataSetup;
    private CustomerSetupFactory $customerSetupFactory;
    private AttributeSetFactory $attributeSetFactory;
    private AttributeResource $attributeResource;

    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory,
        AttributeSetFactory $attributeSetFactory,
        AttributeResource $attributeResource
    ) {
        $this->moduleDataSetup      = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory  = $attributeSetFactory;
        $this->attributeResource    = $attributeResource;
    }

    public function apply(): void
    {
        $this->moduleDataSetup->getConnection()->startSetup();
        $customerSetup  = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSet   = $this->attributeSetFactory->create();
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        $attributes = [
            'loyalty_discount_used' => [
                'label'                  => 'Loyalty Discount Used',
                'type'                   => 'int',
                'input'                  => 'text',
                'required'               => false,
                'default'                => 0,
                'visible'                => true,
                'user_defined'           => true,
                'system'                 => false,
                'is_used_in_grid'        => true,
                'is_visible_in_grid'     => true,
                'is_filterable_in_grid'  => true,
                'position'               => 200,
                'used_in_forms'          => ['adminhtml_customer'],
            ],
            'loyalty_discount_total_limit' => [
                'label'                  => 'Loyalty Discount Total Limit',
                'type'                   => 'int',
                'input'                  => 'text',
                'required'               => false,
                'default'                => 0,
                'visible'                => true,
                'user_defined'           => true,
                'system'                 => false,
                'is_used_in_grid'        => true,
                'is_visible_in_grid'     => true,
                'is_filterable_in_grid'  => true,
                'position'               => 201,
                'used_in_forms'          => ['adminhtml_customer'],
            ],
            'loyalty_last_discounted_order' => [
                'label'                  => 'Loyalty Last Discounted Order',
                'type'                   => 'int',
                'input'                  => 'text',
                'required'               => false,
                'default'                => 0,
                'visible'                => false,
                'user_defined'           => true,
                'system'                 => false,
                'is_used_in_grid'        => false,
                'is_visible_in_grid'     => false,
                'is_filterable_in_grid'  => false,
                'position'               => 202,
                'used_in_forms'          => [],
            ],
        ];

        foreach ($attributes as $code => $config) {
            try {
                $existing = $customerSetup->getEavConfig()->getAttribute('customer', $code);
                if ($existing && $existing->getId()) {
                    continue;
                }
            } catch (\Exception $e) {
                // attribute doesn't exist yet, proceed
            }

            $customerSetup->addAttribute('customer', $code, $config);

            $attribute = $customerSetup->getEavConfig()
                ->getAttribute('customer', $code)
                ->addData([
                    'attribute_set_id'   => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms'      => $config['used_in_forms'],
                ]);
            $this->attributeResource->save($attribute);
        }

        $this->moduleDataSetup->getConnection()->endSetup();
    }

    public static function getDependencies(): array
    {
        return [
            CustomerAttribute::class,
        ];
    }

    public function getAliases(): array
    {
        return [];
    }
}
